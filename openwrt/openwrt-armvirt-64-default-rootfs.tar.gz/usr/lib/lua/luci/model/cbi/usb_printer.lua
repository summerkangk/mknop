require"luci.util"
local e=luci.model.uci.cursor_state()
local i=require"luci.model.network"
m=Map("usb_printer",translate("USB Printer Server"),
translate("Shares multiple USB printers via TCP/IP.<br />When modified bingings, re-plug usb connectors to take effect.<br />This module requires kmod-usb-printer."))
function hex_align(e,t)
local t=t-string.len(e)
return string.rep("0",t)..e
end
function detect_usb_printers()
local i={}
local e=luci.util.execi("/usr/bin/detectlp")
for t in e do
local a={}
local e=string.find(t,",")
local n=string.sub(t,1,e-1)
local t=string.sub(t,e+1,string.len(t))
e=string.find(t,",")
local o=string.sub(t,1,e-1)
t=string.sub(t,e+1,string.len(t))
e=string.find(t,",")
local h=string.sub(t,1,e-1)
local r=string.sub(t,e+1,string.len(t))
e=string.find(o,"/");
local s=string.sub(o,1,e-1)
local t=string.sub(o,e+1,string.len(o))
e=string.find(t,"/")
t=string.sub(t,1,e-1)
a["description"]=r
a["model"]=h
a["id"]=hex_align(s,4)..":"..hex_align(t,4)
a["name"]=n
a["product"]=o
table.insert(i,a)
end
return i
end
local e=detect_usb_printers()
v=m:section(Table,e,translate("Detected printers"))
v:option(DummyValue,"description",translate("Description"))
v:option(DummyValue,"model",translate("Printer Model"))
v:option(DummyValue,"id",translate("VID/PID"))
v:option(DummyValue,"name",translate("Device Name"))
i=i.init(m.uci)
s=m:section(TypedSection,"printer",translate("Bindings"))
s.addremove=true
s.anonymous=true
s:option(Flag,"enabled",translate("enable"))
d=s:option(Value,"device",translate("Device"))
d.rmempty=true
for t,e in ipairs(e)do
d:value(e["product"],e["description"].." ["..e["id"].."]")
end
b=s:option(Value,"bind",translate("Interface"),translate("Specifies the interface to listen on."))
b.template="cbi/network_netlist"
b.nocreate=true
b.unspecified=true
function b.cfgvalue(...)
local e=Value.cfgvalue(...)
if e then
return(i:get_status_by_address(e))
end
end
function b.write(t,a,e)
local e=i:get_network(e)
if e and e:ipaddr()then
Value.write(t,a,e:ipaddr())
end
end
p=s:option(ListValue,"port",translate("Port"),translate("TCP listener port."))
p.rmempty=true
for e=0,9 do
p:value(e,9100+e)
end
s:option(Flag,"bidirectional",translate("Bidirectional mode"))
return m
