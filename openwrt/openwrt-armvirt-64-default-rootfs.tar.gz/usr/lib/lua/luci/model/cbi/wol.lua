local a=require"luci.sys"
local e=require"nixio.fs"
m=SimpleForm("wol",translate("Wake on LAN"),
translate("Wake on LAN is a mechanism to remotely boot computers in the local network."))
m.submit=translate("Wake up host")
m.reset=false
local t=e.access("/usr/bin/etherwake")
local e=e.access("/usr/bin/wol")
s=m:section(SimpleSection)
if t and e then
bin=s:option(ListValue,"binary",translate("WoL program"),
translate("Sometimes only one of the two tools works. If one fails, try the other one"))
bin:value("/usr/bin/etherwake","Etherwake")
bin:value("/usr/bin/wol","WoL")
end
if t then
iface=s:option(ListValue,"iface",translate("Network interface to use"),
translate("Specifies the interface the WoL packet is sent on"))
if e then
iface:depends("binary","/usr/bin/etherwake")
end
iface.default="br-lan"
iface:value("",translate("Broadcast on all interfaces"))
for t,e in ipairs(a.net.devices())do
if e~="lo"then iface:value(e)end
end
end
host=s:option(ListValue,"mac",translate("Host to wake up"),
translate("Choose the host to wake up or enter a custom MAC address to use"))
a.net.mac_hints(function(e,t)
host:value(e,"%s (%s)"%{e,t})
end)
if t then
broadcast=s:option(Flag,"broadcast",
translate("Send to broadcast address"))
broadcast.default="1"
if e then
broadcast:depends("binary","/usr/bin/etherwake")
end
end
function host.write(e,e,e)
local e=luci.http.formvalue("cbid.wol.1.mac")
if e and#e>0 and e:match("^[a-fA-F0-9:]+$")then
local a
local t=luci.http.formvalue("cbid.wol.1.binary")or(
t and"/usr/bin/etherwake"or"/usr/bin/wol"
)
if t=="/usr/bin/etherwake"then
local o=luci.http.formvalue("cbid.wol.1.iface")
local i=luci.http.formvalue("cbid.wol.1.broadcast")
a="%s -D%s %s %q"%{
t,(o~=""and" -i %q"%o or""),
(i=="1"and" -b"or""),e
}
else
a="%s -v %q"%{t,e}
end
local t="<p><strong>%s</strong><br /><br /><code>%s<br /><br />"%{
translate("Starting WoL utility:"),a
}
local a=io.popen(a.." 2>&1")
if a then
while true do
local e=a:read("*l")
if e then
if#e>100 then e=e:sub(1,100).."..."end
t=t..e.."<br />"
else
break
end
end
a:close()
end
t=t.."</code></p>"
m.message=t
end
end
return m
