local e=require"nixio.fs"
local a="/tmp/unblockmusic.log"
local a="/tmp/music.log"
f=SimpleForm("logview")
t=f:field(TextValue,"conf")
t.rmempty=true
t.rows=20
function t.cfgvalue()
luci.sys.exec("grep -B 1 'http' /tmp/unblockmusic.log > /tmp/music.log")
return e.readfile(a)or""
end
t.readonly="readonly"
return f
